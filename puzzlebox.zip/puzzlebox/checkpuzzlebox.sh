#!/bin/bash

# 1 = contains file or is a file
# 2 = empty folder
# 3 = does not exist

#mydir="catishere"
#mydir="emptyfolder"
#mydir="doesnotexist"


checkThis () {

# pgone
files=$(shopt -s nullglob dotglob; echo $1*)
if (( ${#files}==0 ))
then
    pgone=2
else
    pgone=1
fi


# pgtwo
if [ -n "$(find $1 -prune -empty -type d 2>/dev/null)" ]
then
    pgtwo=2
else
    pgtwo=1
fi


if [[ $pgone -eq 1 && $pgtwo -eq 1 ]]; then
    return 1
elif [[ $pgone -eq 1 && $pgtwo -eq 2 ]]; then
    return 2
elif [[ $pgone -eq 2 && $pgtwo -eq 1 ]]; then
    return 3
else
   return 0
fi

}


#TRUE | PG1 | PG2
#  y     y     y
#  e     y     en
#  n     en    y

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


checkThis "allShapes"
if [[ $? -ne 2 ]]; then
    echo "allShapes is not empty!"
    exit 1
fi

checkThis "circleHole"
if [[ $? -ne 1 ]]; then
    echo "circleHole is wrong!"
    exit 1
fi

checkThis "circleHole/circleBlock"
if [[ $? -ne 1 ]]; then
    echo "circleHole is wrong!"
    exit 1
fi

checkThis "pentagonHole"
if [[ $? -ne 1 ]]; then
    echo "pentagonHole is wrong!"
    exit 1
fi

checkThis "pentagonHole/pentagonBlock"
if [[ $? -ne 1 ]]; then
    echo "pentagonHole is wrong!"
    exit 1
fi

checkThis "pentagonHole/garbage"
if [[ $? -ne 3 ]]; then
    echo "pentagonHole is wrong!"
    exit 1
fi

checkThis "squareHole"
if [[ $? -ne 1 ]]; then
    echo "squareHole is wrong!"
    exit 1
fi

checkThis "squareHole/squareBlock.txt"
if [[ $? -ne 1 ]]; then
    echo "squareHole is wrong!"
    exit 1
fi

checkThis "whenEverythingIsSortedGoHere/complete.txt"
if [[ $? -ne 1 ]]; then
    echo "whenEverythingIsSortedGoHere is wrong!"
    exit 1
fi

echo " "
echo "YOU WIN!!"
echo "GOOD JOB!!! :D"
echo "mr. cow will be pleased"
echo " "
echo " _______
< i am proud of you >
 -------
        \   ^__^
         \  (oO)\_______
            (__)\       )\_
             V ||----w |
                ||     || "

